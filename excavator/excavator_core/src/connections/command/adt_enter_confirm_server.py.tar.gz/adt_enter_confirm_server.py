#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy

from doosan_msgs.srv import ADTEnterConfirm, ADTEnterConfirmRequest, ADTEnterConfirmResponse

class ADTEnterConfirmServer:

    def __init__(self):
        
        rospy.Service('/excavator/command/enter_confirm', ADTEnterConfirm, self.__handle_adt_enter_confirm)


    # 
    #   machine_type    : uint16
    #   machine_id      : string
    #   geo_fence_id    : uint32
    # 
    def __handle_adt_enter_confirm(self, request):
        machine_type = request.machine_type
        machine_id = request.machine_id
        geo_fence_id = request.geo_fence_id

        # 
        #   TODO IMPLEMENTS ADT ENTER CONFIRM HANDLER
        # 


        return request.SUCCESS


def main():
    rospy.init_node('excavator_core_adt_enter_confirm_server', anonymous=True)
    try:
        adt_enter_confirm_server = ADTEnterConfirmServer()
    except rospy.ROSInterruptException:
        pass

if __name__ == '__main__':
    main()